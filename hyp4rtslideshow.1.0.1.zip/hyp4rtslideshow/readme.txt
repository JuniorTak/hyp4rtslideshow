=== Hyp Slideshow ===

Contributors:      Hyppolite T.
Tested up to:      6.7
Stable tag:        1.0
License:           GPLv2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html
Tags:              slider, slideshow, shortcode

Hyp Slideshow is a plugin to generate a slideshow for users to add into their websites.

== Description ==

Hyp Slideshow allows users to add slideshow add their website's pages or posts using a shortcode. It comes with a settings page which allows to upload, redorder, or delete slideshow images.

== Installation ==

1. Download the [plugin .zip file](https://github.com/JuniorTak/hyp4rtslideshow/raw/main/hyp4rtslideshow.1.0.1.zip)
2. In the site dashboard, visit **Plugins**.
3. Click **Add New Plugin**, then click **Upload Plugin**.
3. Click **Choose File** and load the plugin .zip file you just downloaded, then click **Install Now**.
4. Once the installation is complete, activate the Hyp Slideshow plugin.

== Usage ==

1. In the site dashboard, visit **HypSlideshow** to access the plugin settings page.
2. Add images to display in the slideshow, you can also remove and reorder images.
3. Add the shortcode `[hypslideshow]` on a page/post where you want to display the slideshow.
4. In the front-side of your WordPress site, visit the page/post to see the slideshow in action.

== Frequently Asked Questions ==

= Where can I contribute to the plugin? =

All development for this plugin is handled via [GitHub](https://github.com/JuniorTak/hyp4rtslideshow/) any issues or pull requests should be posted there.


== Changelog ==

= 1.0.1 =
* Add - Initial multisite support.
* Fix - Enforce plugin security and best practices including all checks.
* Fix - Ensure plugin settings page properly handles images upload, reorder and removal for the slideshow.
* Fix - Ensure plugin shortcode displays a message for no image, a static image for a signle image, or images slider for multiple images.

= 1.0.0 =
* Add - Initial release.
* Feature - Complete overhaul of the plugin and its architecture.

= [0.1] 2024-07-10 =

Original development version of the slideshow plugin for reference only.